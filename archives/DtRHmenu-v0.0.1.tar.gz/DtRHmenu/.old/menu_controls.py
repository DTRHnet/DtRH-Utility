import json
import sys
import curses

class Menu:
    def __init__(self, config):
        self.config = config
        self.current_menu = 'main'
        self.menus = {'main': config}
        self.theme = config['theme']
        self.language = config['language']
        self.selected_index = 0
        self.history = []

    def get_menu_title(self):
        menu = self.menus[self.current_menu]
        return self.config['languages'][self.language].get(menu['menu_title'], menu['menu_title'])

    def get_menu_items(self):
        menu = self.menus[self.current_menu]
        return menu['menu_items']

    def display(self, stdscr):
        curses.curs_set(0)  # Hide the cursor
        stdscr.clear()
        h, w = stdscr.getmaxyx()
        title = self.get_menu_title()
        x = w // 2 - len(title) // 2
        y = h // 2 - len(self.get_menu_items()) // 2 - 1
        stdscr.addstr(y, x, title, curses.A_BOLD)
        
        for idx, item in enumerate(self.get_menu_items()):
            label = self.config['languages'][self.language].get(item['label'], item['label'])
            x = w // 2 - len(label) // 2
            y = h // 2 - len(self.get_menu_items()) // 2 + idx + 1
            if idx == self.selected_index:
                stdscr.attron(curses.color_pair(1))
                stdscr.addstr(y, x, label)
                stdscr.attroff(curses.color_pair(1))
            else:
                stdscr.addstr(y, x, label)

        stdscr.refresh()

    def run(self, stdscr):
        curses.start_color()
        curses.init_pair(1, self.get_color(self.theme['highlight_color']), curses.COLOR_BLACK)
        
        while True:
            self.display(stdscr)
            key = stdscr.getch()

            if key == curses.KEY_UP and self.selected_index > 0:
                self.selected_index -= 1
            elif key == curses.KEY_DOWN and self.selected_index < len(self.get_menu_items()) - 1:
                self.selected_index += 1
            elif key == curses.KEY_ENTER or key in [10, 13]:
                self.execute_action(self.get_menu_items()[self.selected_index]['action'], stdscr)

    def execute_action(self, action, stdscr):
        item = self.get_menu_items()[self.selected_index]
        if action == "start_game":
            print("Starting game...")
        elif action == "exit":
            sys.exit(0)
        elif action == "submenu":
            submenu_id = item['submenu']
            self.history.append(self.current_menu)
            self.current_menu = submenu_id
        elif action == "back":
            self.current_menu = self.history.pop()
        elif action == "input":
            self.handle_input(item, stdscr)
        elif action == "multiple_select":
            self.handle_multiple_select(item, stdscr)
        # Add more actions here

    def handle_input(self, item, stdscr):
        curses.echo()
        stdscr.clear()
        h, w = stdscr.getmaxyx()
        prompt = item['label'] + ": "
        stdscr.addstr(h // 2, w // 2 - len(prompt) // 2, prompt)
        stdscr.refresh()
        input_value = stdscr.getstr(h // 2, w // 2 + len(prompt) // 2).decode('utf-8')
        curses.noecho()
        # Process input_value as needed
        print(f"Input received: {input_value}")

    def handle_multiple_select(self, item, stdscr):
        options = item['options']
        selected_options = []
        idx = 0
        while True:
            stdscr.clear()
            h, w = stdscr.getmaxyx()
            for i, option in enumerate(options):
                x = w // 2 - len(option) // 2
                y = h // 2 - len(options) // 2 + i
                if i == idx:
                    stdscr.attron(curses.color_pair(1))
                    stdscr.addstr(y, x, option)
                    stdscr.attroff(curses.color_pair(1))
                else:
                    stdscr.addstr(y, x, option)
            stdscr.refresh()
            key = stdscr.getch()
            if key == curses.KEY_UP and idx > 0:
                idx -= 1
            elif key == curses.KEY_DOWN and idx < len(options) - 1:
                idx += 1
            elif key == curses.KEY_ENTER or key in [10, 13]:
                selected_options.append(options[idx])
                break
        # Process selected_options as needed
        print(f"Selected options: {selected_options}")

    def get_color(self, color_name):
        colors = {
            "black": curses.COLOR_BLACK,
            "red": curses.COLOR_RED,
            "green": curses.COLOR_GREEN,
            "yellow": curses.COLOR_YELLOW,
            "blue": curses.COLOR_BLUE,
            "magenta": curses.COLOR_MAGENTA,
            "cyan": curses.COLOR_CYAN,
            "white": curses.COLOR_WHITE
        }
        return colors.get(color_name, curses.COLOR_WHITE)

def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            config = json.load(f)
    else:
        config = json.load(sys.stdin)

    menu = Menu(config)
    curses.wrapper(menu.run)

if __name__ == "__main__":
    main()
