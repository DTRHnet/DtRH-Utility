from rich.console import Console

console = Console()

def action_1():
    console.print("[bold green]Action 1:[/bold green] Executing task for option 1...")
    # Add the actual code for action 1 here
    console.print("[bold green]Action 1 Completed![/bold green]")

def action_2():
    console.print("[bold blue]Action 2:[/bold blue] Performing operation for option 2...")
    # Add the actual code for action 2 here
    console.print("[bold blue]Action 2 Completed![/bold blue]")

def action_3():
    console.print("[bold red]Action 3:[/bold red] Running process for option 3...")
    # Add the actual code for action 3 here
    console.print("[bold red]Action 3 Completed![/bold red]")

def default_action():
    console.print("[bold yellow]Invalid option selected.[/bold yellow] Please try again.")
