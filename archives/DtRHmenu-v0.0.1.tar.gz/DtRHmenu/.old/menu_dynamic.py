import json
import sys
import curses

class Menu:
    def __init__(self, config):
        self.title = config['menu_title']
        self.items = config['menu_items']
        self.theme = config['theme']
        self.selected_index = 0

    def display(self, stdscr):
        curses.curs_set(0)  # Hide the cursor
        stdscr.clear()
        h, w = stdscr.getmaxyx()
        x = w // 2 - len(self.title) // 2
        y = h // 2 - len(self.items) // 2 - 1
        stdscr.addstr(y, x, self.title, curses.A_BOLD)
        
        for idx, item in enumerate(self.items):
            x = w // 2 - len(item['label']) // 2
            y = h // 2 - len(self.items) // 2 + idx + 1
            if idx == self.selected_index:
                stdscr.attron(curses.color_pair(1))
                stdscr.addstr(y, x, item['label'])
                stdscr.attroff(curses.color_pair(1))
            else:
                stdscr.addstr(y, x, item['label'])

        stdscr.refresh()

    def run(self, stdscr):
        curses.start_color()
        curses.init_pair(1, curses.COLOR_CYAN, curses.COLOR_BLACK)
        
        while True:
            self.display(stdscr)
            key = stdscr.getch()

            if key == curses.KEY_UP and self.selected_index > 0:
                self.selected_index -= 1
            elif key == curses.KEY_DOWN and self.selected_index < len(self.items) - 1:
                self.selected_index += 1
            elif key == curses.KEY_ENTER or key in [10, 13]:
                action = self.items[self.selected_index]['action']
                if action == 'exit':
                    break
                else:
                    self.execute_action(action)

    def execute_action(self, action):
        if action == "start_game":
            print("Starting game...")
        elif action == "options":
            print("Options selected...")
        # Add more actions here

def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            config = json.load(f)
    else:
        config = json.load(sys.stdin)

    menu = Menu(config)
    curses.wrapper(menu.run)

if __name__ == "__main__":
    main()
