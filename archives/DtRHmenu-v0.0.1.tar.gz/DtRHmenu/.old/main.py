from rich.prompt import Prompt
from menu import load_menu_config, validate_menu_config, display_menu
import actions

def main():
    menu_config = load_menu_config()
    if not validate_menu_config(menu_config):
        return
    
    menu = menu_config['main_menu']
    display_menu(menu)
    selected_option = Prompt.ask("Please select an option")

    # Mapping actions to their corresponding functions
    action_map = {
        "action_1": actions.action_1,
        "action_2": actions.action_2,
        "action_3": actions.action_3
    }

    # Execute the corresponding action or the default action
    action_map.get(selected_option, actions.default_action)()

if __name__ == "__main__":
    main()
