]#!/bin/bash
# 
# repo_script.sh - Basic script to create a new github repo based on the variables below. Simplifies 
#                  the pprocess and takes a second or two to initialize remote and local repositories.
#
#  >  https://dtrh.net
#  >  KBS  < admin [at] dtrh.net >



# SET VARS BEFORE RUNNING ----------------------------
GITHUB_USERNAME="DTRHnet"	# ex. DTRHnet
GITHUB_EMAIL="admin@dtrh.net"     	# ex. admin@dtrh.net
REPO_NAME="dtrhUtility-repo"		# ex. Personal-Scripts
REPO_DESCRIPTION=""
GITHUB_API_URL="https://api.github.com/user/repos"
ACCESS_TOKEN="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"		# PAT as created and scoped via ( Settings -> Developer Settings -> Access Tokens (classic) )

# ENSURE GIT EXISTS ----------------------------------
if ! [ -x "$(command -v git)" ]; then
  echo "Error: Git is not installed." >&2
  exit 1
fi

# CONFIGURE USER DETAILS -----------------------------
git config --global user.name "$GITHUB_USERNAME"
git config --global user.email "$GITHUB_EMAIL"

# CREATE REPO ----------------------------------------
echo "Creating repository $REPO_NAME on GitHub..."
curl -H "Authorization: token $ACCESS_TOKEN" \
     -d "{\"name\":\"$REPO_NAME\", \"description\":\"$REPO_DESCRIPTION\", \"private\":false}" \
     $GITHUB_API_URL

# ERROR CHECK REPO CREATION --------------------------
if [ $? -ne 0 ]; then
  echo "Error: Failed to create repository on GitHub." >&2
  exit 1
fi

# INITIALIZE LOCAL REPO ------------------------------
mkdir $REPO_NAME
cd $REPO_NAME
git init

# ADD README.md TO LOCAL REPO ------------------------
echo "# $REPO_NAME" > README.md
echo "" >> README.md
echo "$REPO_DESCRIPTION" >> README.md

# ADD AND COMMIT -------------------------------------
git add README.md
git commit -m "Initial commit"

# ADD REMOTE ORIGIN AND PUSH -------------------------
git remote add origin https://$GITHUB_USERNAME:$ACCESS_TOKEN@github.com/$GITHUB_USERNAME/$REPO_NAME.git
git push -u origin master

echo "Repository $REPO_NAME created and initial commit pushed to GitHub."

# EXIT WITHOUT ERROR ---------------------------------
exit 0
